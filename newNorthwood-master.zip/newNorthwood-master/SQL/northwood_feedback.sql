INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('peiyuan.chen@smu.ca', 'I like steak so much', '2018-11-11 04:41:47');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('peiyuan.chen@smu.ca', 'I like the Butter Chicken very much!!!', '2018-11-11 06:05:53');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('peiyuan.chen@smu.ca', 'Apple Pie is good', '2018-11-25 20:59:35');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('patrick@gmail.com', 'Noodle is good today', '2018-11-26 14:04:14');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('emacleod88@gmail.com', 'cake', '2018-11-30 16:53:14');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('emacleod88@gmail.com', 'cake', '2018-11-30 16:53:28');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('null', '', '2018-11-30 17:24:38');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('emacleod88@gmail.com', 'null', '2018-11-30 17:24:54');
INSERT INTO northwood.feedback (user_email, fb_content, fb_time) VALUES ('emacleod88@gmail.com', '', '2018-11-30 17:25:03');