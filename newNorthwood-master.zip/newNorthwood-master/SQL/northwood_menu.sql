INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (25, 'Apple Juice', '2018-11-25 20:42:59', 'Sunday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (27, 'Noodle', '2018-11-25 20:43:11', 'Tuesday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (28, 'Pineapple', '2018-11-25 20:43:17', 'Wednesday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (30, 'Butter Chicken', '2018-11-25 20:44:22', 'Friday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (31, 'Chicken Noodle', '2018-11-26 13:54:00', 'Monday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (33, 'Fish', '2018-11-26 13:54:00', 'Monday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (34, 'Banana', '2018-11-26 13:48:25', 'Monday');
INSERT INTO northwood.menu (ID, content, add_date, Day) VALUES (35, 'Apple Pie', '2018-11-26 13:50:03', 'Monday');