INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (25, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (27, 0, 0, 1);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (28, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (30, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (31, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (33, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (34, 0, 0, 0);
INSERT INTO northwood.vote_result (dish_id, like_dish, dislike_dish, want_more_dish) VALUES (35, 0, 0, 0);